**Challenge**:
Your main goal is to take the given HTML for a blog post and make it look good using CSS.

**Hints:**
 - Think about CSS fonts & colors.
 - The Box Model will come in handy here.

**Topics Covered:**
 - Typography
 - Colors
 - Box Model

**Other Information:**
 - Font used: Lato
 - Author text color: #ef5839
 - Bold font weight: 900
